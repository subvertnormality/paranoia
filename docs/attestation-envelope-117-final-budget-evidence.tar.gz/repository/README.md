# Release record fixture
Record the release date in release-notes.md.
