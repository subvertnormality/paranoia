from helpers import (
    json, hashlib, re, Path, Any, deepcopy, urlparse, Audit, AuditError,
    AUDIT_MARKER, MAX_ACTIVE_CLAIMS, DIAGNOSTIC_CHARS, _excerpt,
    _validate_claim, _validate_dispositions, _validate_assessments, _one_line,
)

def parse_audit(
    text: str, plan_text: str, *, allow_partial: bool = False,
    repo: Path | None = None, plan_repo_path: str | None = None,
    require_capture_provenance: bool = False,
) -> Audit:
    """Parse and validate the single JSON object following ``AUDIT_MARKER``."""
    if text.count(AUDIT_MARKER) != 1:
        raise AuditError(
            f"expected exactly one {AUDIT_MARKER!r} marker, found {text.count(AUDIT_MARKER)}",
            text,
        )
    tail = text.split(AUDIT_MARKER, 1)[1].strip()
    if tail.startswith("```json"):
        tail = tail[7:].lstrip()
    elif tail.startswith("```"):
        tail = tail[3:].lstrip()
    try:
        value, end = json.JSONDecoder().raw_decode(tail)
    except json.JSONDecodeError as exc:
        raise AuditError(f"claim audit JSON did not parse: {exc}", text) from exc
    remainder = tail[end:].strip()
    if remainder == "```":
        remainder = ""
    if remainder:
        raise AuditError("unexpected text after claim audit JSON", text)
    if not isinstance(value, dict) or set(value) != {"claims", "coverage"}:
        raise AuditError("audit must be an object with exactly claims and coverage", text)
    claims, coverage = value["claims"], value["coverage"]
    if not isinstance(claims, list):
        raise AuditError("claims must be an array", text)
    if len(claims) > MAX_ACTIVE_CLAIMS:
        raise AuditError(
            f"audit returned {len(claims)} active claims; safety ceiling is {MAX_ACTIVE_CLAIMS}",
            text,
        )
    if not isinstance(coverage, dict):
        raise AuditError("coverage must be an object", text)

    validated: list[dict[str, Any]] = []
    issues: list[str] = []
    seen: set[tuple[str, str]] = set()
    for index, item in enumerate(claims):
        try:
            claim = _validate_claim(
                item, plan_text, repo=repo, plan_repo_path=plan_repo_path,
                require_capture_provenance=require_capture_provenance,
            )
        except ValueError as exc:
            reason = f"claim {index}: {exc}"
            if not allow_partial:
                raise AuditError(reason, text) from exc
            issues.append(f"{reason}; item={_excerpt(json.dumps(item, ensure_ascii=False))}")
            continue
        identity = (claim["anchor"], claim["proposition"])
        if identity in seen:
            reason = f"claim {index}: duplicate anchor and proposition"
            if not allow_partial:
                raise AuditError(reason, text)
            issues.append(f"{reason}; item={_excerpt(json.dumps(item, ensure_ascii=False))}")
            continue
        seen.add(identity)
        validated.append(claim)
    for field in ("prior_dispositions", "prior_assessments"):
        if field not in coverage:
            raise AuditError(f"coverage.{field} is required", text)
    dispositions = _validate_dispositions(coverage["prior_dispositions"], text)
    assessments = _validate_assessments(coverage["prior_assessments"], text)
    return Audit(
        tuple(validated), deepcopy(coverage), dispositions, assessments, tuple(issues),
        hashlib.sha256(text.encode("utf-8", "replace")).hexdigest(),
        _excerpt("\n".join(issues)),
    )
