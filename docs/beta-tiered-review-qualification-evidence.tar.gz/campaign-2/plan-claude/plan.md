# Plan: status endpoint

## Behaviour

1. Responses: `GET /status` returns HTTP 200 with JSON body `{"ok": true}` only when the database check succeeds (rule 2); every other outcome returns HTTP 503 with JSON body `{"ok": false}`. Both use `Content-Type: application/json`. These two responses are defined only here; other sections refer to rule 1.
2. Database check: the check succeeds only when the probe returns exactly `True` within a single 2-second budget that covers the whole check. A `False` return, any exception, or no result within the budget is a failure.
3. Retries: exactly one probe runs per request and it is never retried.
4. Latency: the worst-case response time is the 2-second budget plus response serialization. An unfinished probe is abandoned at the deadline, never awaited.
5. Status semantics: per RFC 9110, status code 503 means Service Unavailable, which is the meaning intended by rule 1.

## Implementation

- `app.py` (new) defines `handle_status(probe, timeout_seconds=2.0) -> tuple[int, bytes]`. It starts `probe` once in a daemon `threading.Thread`, calls `join(timeout=timeout_seconds)`, and treats the check as successful only if the thread finished and recorded a return value that `is True`. It maps success to a status code by reusing the existing `status(db_ok)` in `service.py`, and returns that code with the matching rule 1 body.
- `app.py` also defines `StatusHandler(http.server.BaseHTTPRequestHandler)`, whose `do_GET` serves `/status` by calling `handle_status(self.server.probe)` and writing the returned status, the rule 1 content type and the body; any other path returns 404. `make_server(probe, host, port)` builds a `http.server.ThreadingHTTPServer` with `StatusHandler` and stores `probe` on the server. `main()` serves `make_server(sqlite_probe, "127.0.0.1", 8080)`.
- Database: the service's database is the SQLite file named by the environment variable `STATUS_DB_PATH`. `sqlite_probe()` opens it with `sqlite3.connect(f"file:{path}?mode=rw", uri=True, timeout=2.0)` so that a missing file fails instead of being created, executes `SELECT 1`, returns `cursor.fetchone() == (1,)`, and closes the connection in a `finally` block.
- Cleanup: an abandoned probe thread ends no later than its own 2-second SQLite lock timeout and closes its connection in `finally`; each request starts at most one probe thread (rule 3).
- Scope: the new `app.py`, the new `test_service.py`, and a `README.md` section that points to rules 1 to 4. No third-party package is added.

## Acceptance

`python -m unittest test_service` must pass. Every test asserts both the HTTP status and the parsed JSON body required by rule 1.

- `test_true_probe_is_healthy`, `test_false_probe_is_unavailable`, `test_raising_probe_is_unavailable` call `handle_status` with stub probes that return `True`, return `False`, and raise `RuntimeError`.
- `test_slow_probe_times_out` calls `handle_status(probe, timeout_seconds=0.2)` with a probe that sleeps 1 second, asserts the unavailable response, and asserts the call returned within 0.7 seconds measured with `time.monotonic()`.
- `test_probe_runs_once` uses a counting stub on the raising and slow paths and asserts exactly one invocation each (rule 3).
- `test_get_status_over_http` starts `make_server(probe, "127.0.0.1", 0)` in a background thread, requests `GET /status` with `urllib.request` for a `True` probe and for a raising probe, asserts both responses, and shuts the server down.
- `test_sqlite_probe` creates a temporary SQLite file and asserts `handle_status(sqlite_probe)` is healthy with `STATUS_DB_PATH` pointing at it, and unavailable with `STATUS_DB_PATH` pointing at a file that does not exist.

Any failing test blocks merge.
