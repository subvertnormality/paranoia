# Plan: status endpoint

## Behaviour

1. Responses: `GET /status` returns HTTP 200 with JSON body `{"ok": true}` only when the database check succeeds (rule 2); every other outcome returns HTTP 503 with JSON body `{"ok": false}`. Both use `Content-Type: application/json`. These two responses are defined only here; other sections refer to rule 1.
2. Database check: `handle_status` computes an absolute deadline as `time.monotonic()` at entry plus a 2-second budget. The check succeeds only when the probe reports exactly `True` before that deadline. A `False` report, any exception, or no report before the deadline is a failure, and nothing reported after the deadline can change the chosen response.
3. Retries: exactly one probe runs per request and it is never retried.
4. Latency and cleanup: the response is chosen at the deadline at the latest, and the probe's worker process is stopped before the response is written (see Implementation).

## Implementation

- `app.py` (new) defines `handle_status(probe, timeout_seconds=2.0) -> tuple[int, bytes]`. It computes the rule 2 deadline, starts `probe` once in a child process created with `multiprocessing.get_context("spawn").Process`, and receives the probe's result over a one-way `Pipe`. It waits with `connection.poll(max(0.0, deadline - time.monotonic()))`; if no result is available at the deadline it calls `terminate()`, then `join(0.5)`, then `kill()` and `join()` if the process is still alive, and treats the check as failed. A result read before the deadline counts only if it is exactly `True`. Probes are module-level functions so the spawn context can import them. It maps the outcome to a status code by reusing the existing `status(db_ok)` in `service.py` and returns that code with the matching rule 1 body.
- `app.py` also defines `StatusHandler(http.server.BaseHTTPRequestHandler)`, whose `do_GET` serves `/status` by calling `handle_status(self.server.probe, self.server.timeout_seconds)` and writing the returned status, the rule 1 content type and the body; any other path returns 404. `make_server(probe, host, port, timeout_seconds=2.0)` builds a `http.server.ThreadingHTTPServer` with `StatusHandler` and stores `probe` and `timeout_seconds` on the server. `main()` serves `make_server(sqlite_probe, "127.0.0.1", 8080)`.
- Database: the service's database is the SQLite file named by the environment variable `STATUS_DB_PATH`. `sqlite_probe()` raises `FileNotFoundError` unless `os.path.isfile(path)` is true, so a missing file is never created, and then opens exactly that filename with `sqlite3.connect(path)` without URI parsing. It runs `SELECT count(*) FROM sqlite_master`, closes the connection in a `finally` block, and reports `True` only when the query returned one row.
- Scope: the new `app.py`, the new `test_service.py`, and a `README.md` section that points to rules 1 to 4. No third-party package is added.

## Acceptance

`python -m unittest test_service` must pass. Every check goes through `GET /status` on a server built by `make_server(probe, "127.0.0.1", 0, timeout_seconds=0.2)` in a background thread, requested with `urllib.request`, and asserts both the HTTP status and the parsed JSON body required by rule 1. The server is shut down after each test. The 0.5-second tolerance used below covers spawning the child process, stopping it and the local HTTP round trip on the test machine; a slower machine must raise it explicitly in the test rather than weaken the assertions.

- `test_true_probe_is_healthy`, `test_false_probe_is_unavailable` and `test_raising_probe_is_unavailable` use module-level stub probes that return `True`, return `False`, and raise `RuntimeError`.
- `test_slow_probe_times_out` uses a probe that sleeps 5 seconds and then returns `True`. It asserts the unavailable response, that the request completed within the 0.2-second budget plus the 0.5-second tolerance measured with `time.monotonic()` around the request, and that no child process started by the request is still alive when the response arrives (`multiprocessing.active_children()` is empty).
- `test_probe_runs_once` records each probe invocation in a temporary file and asserts exactly one invocation per request on the raising and slow paths (rule 3).
- `test_sqlite_probe` serves `sqlite_probe` with `STATUS_DB_PATH` set to a temporary SQLite database (healthy), to a missing path (unavailable, and the file is still absent afterwards), and to a temporary text file that is not a database (unavailable).
- `test_sqlite_path_is_not_a_uri` sets `STATUS_DB_PATH` to a path in a temporary directory whose filename is literally `db?mode=memory`: while no such file exists the endpoint is unavailable and the directory stays empty; after a real SQLite database is created at exactly that filename the endpoint is healthy and the directory contains only that file.

Any failing test blocks merge.
