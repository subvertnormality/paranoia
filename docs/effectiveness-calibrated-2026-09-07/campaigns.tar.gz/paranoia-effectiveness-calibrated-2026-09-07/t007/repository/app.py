def reserve(state, amount):
    if amount > state['available']:
        return False
    state['available'] -= amount
    return True
