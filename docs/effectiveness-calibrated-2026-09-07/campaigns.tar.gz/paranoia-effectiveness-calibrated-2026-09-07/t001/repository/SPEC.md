Review app.py against this specification. helpers.py supplies the documented fixture context and is not a proposed change. Callers enforce the stated input domain. Do not execute repository code. Missing tests alone are not a contract defect. Identify concrete reachable violations, not optional enhancements.

overlap(a,b) returns whether two half-open integer intervals share any point. Each interval is a pair (start,end) with start <= end. Empty intervals share no points.
