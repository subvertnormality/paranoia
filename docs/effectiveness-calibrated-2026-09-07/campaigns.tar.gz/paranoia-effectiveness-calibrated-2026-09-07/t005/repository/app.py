def reserve(state, amount):
    state['available'] -= amount
    if state['available'] < 0:
        return False
    return True
