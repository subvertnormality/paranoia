from helpers import (
    json, hashlib, re, Path, Any, deepcopy, urlparse, Audit, AuditError,
    AUDIT_MARKER, MAX_ACTIVE_CLAIMS, DIAGNOSTIC_CHARS, _excerpt,
    _validate_claim, _validate_dispositions, _validate_assessments, _one_line,
)

def _validate_capture_attestations(
    value: Any, evidence: list[dict[str, str]],
) -> list[dict[str, Any]]:
    if not isinstance(value, list) or len(value) > len(evidence):
        raise ValueError("capture_attestations must contain at most one row per evidence item")
    required = {
        "evidence_index", "final_url", "text_sha256", "relation",
        "publisher_authority", "authority_reason", "passage_entailment",
        "entailment_reason",
    }
    rows: list[dict[str, Any]] = []
    seen: set[int] = set()
    for row in value:
        if not isinstance(row, dict) or set(row) != required:
            raise ValueError("capture_attestation fields are invalid")
        index = row["evidence_index"]
        if type(index) is not int or not 0 <= index < len(evidence) or index in seen:
            raise ValueError("capture_attestation evidence_index is invalid or duplicated")
        seen.add(index)
        final_url = _one_line(row["final_url"], "capture_attestation.final_url")
        parsed = urlparse(final_url)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise ValueError("capture_attestation final_url must be absolute HTTP(S)")
        text_sha256 = _one_line(
            row["text_sha256"], "capture_attestation.text_sha256",
        )
        if not re.fullmatch(r"[0-9a-f]{64}", text_sha256):
            raise ValueError("capture_attestation text_sha256 must be lowercase SHA-256")
        relation = _one_line(row["relation"], "capture_attestation.relation")
        if relation != evidence[index]["relation"]:
            raise ValueError("capture_attestation relation differs from its evidence item")
        if final_url != evidence[index]["url"]:
            raise ValueError("capture_attestation final_url differs from its evidence URL")
        for field in ("publisher_authority", "passage_entailment"):
            if type(row[field]) is not bool:
                raise ValueError(f"capture_attestation {field} must be boolean")
        rows.append({
            "evidence_index": index,
            "final_url": final_url,
            "text_sha256": text_sha256,
            "relation": relation,
            "publisher_authority": row["publisher_authority"],
            "authority_reason": _one_line(
                row["authority_reason"], "capture_attestation.authority_reason",
            ),
            "passage_entailment": row["passage_entailment"],
            "entailment_reason": _one_line(
                row["entailment_reason"], "capture_attestation.entailment_reason",
            ),
        })
    return rows

def _validate_replacement_attestations(
    value: Any, evidence: list[dict[str, str]],
) -> list[dict[str, Any]]:
    if not isinstance(value, list) or len(value) > len(evidence):
        raise ValueError("capture_attestations must contain at most one row per evidence item")
    required = {
        "evidence_index", "final_url", "text_sha256", "relation",
        "publisher_authority", "authority_reason", "passage_entailment",
        "entailment_reason",
    }
    rows: list[dict[str, Any]] = []
    seen: set[int] = set()
    for row in value:
        if not isinstance(row, dict) or set(row) != required:
            raise ValueError("capture_attestation fields are invalid")
        index = row["evidence_index"]
        if type(index) is not int or not 0 <= index < len(evidence) or index in seen:
            raise ValueError("capture_attestation evidence_index is invalid or duplicated")
        seen.add(index)
        final_url = _one_line(row["final_url"], "capture_attestation.final_url")
        parsed = urlparse(final_url)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise ValueError("capture_attestation final_url must be absolute HTTP(S)")
        text_sha256 = _one_line(
            row["text_sha256"], "capture_attestation.text_sha256",
        )
        if not re.fullmatch(r"[0-9a-f]{64}", text_sha256):
            raise ValueError("capture_attestation text_sha256 must be lowercase SHA-256")
        relation = _one_line(row["relation"], "capture_attestation.relation")
        if relation != evidence[index]["relation"]:
            raise ValueError("capture_attestation relation differs from its evidence item")
        if final_url != evidence[index]["url"]:
            raise ValueError("capture_attestation final_url differs from its evidence URL")
        for field in ("publisher_authority", "passage_entailment"):
            if type(row[field]) is not bool:
                raise ValueError(f"capture_attestation {field} must be boolean")
        rows.append({
            "evidence_index": index,
            "final_url": final_url,
            "text_sha256": text_sha256,
            "relation": relation,
            "publisher_authority": row["publisher_authority"],
            "authority_reason": _one_line(
                row["authority_reason"], "capture_attestation.authority_reason",
            ),
            "passage_entailment": row["passage_entailment"],
            "entailment_reason": _one_line(
                row["entailment_reason"], "capture_attestation.entailment_reason",
            ),
        })
    return rows
