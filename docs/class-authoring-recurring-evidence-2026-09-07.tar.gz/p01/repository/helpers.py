import json
import hashlib
import re
from pathlib import Path
from typing import Any
from copy import deepcopy
from urllib.parse import urlparse
from dataclasses import dataclass

AUDIT_MARKER = "=== CLAIM AUDIT JSON ==="
MAX_ACTIVE_CLAIMS = 100
DIAGNOSTIC_CHARS = 8000

class AuditError(ValueError):
    def __init__(self, reason, raw):
        self.reason = reason
        self.raw = raw
        super().__init__(reason)

@dataclass
class Audit:
    claims: tuple
    coverage: dict
    prior_dispositions: tuple
    prior_assessments: tuple
    issues: tuple
    digest: str
    excerpt: str

def _excerpt(text):
    return text[:2000]

def _validate_claim(item, plan_text, **kwargs):
    if not isinstance(item, dict) or set(item) != {"anchor", "proposition"}:
        raise ValueError("claim fields invalid")
    if not all(isinstance(v, str) and v.strip() for v in item.values()):
        raise ValueError("claim text invalid")
    if "whole" in item["proposition"].lower().split() and "whole" not in plan_text.lower().split():
        raise ValueError("proposition introduces whole absent from plan wording")
    return dict(item)

def _validate_dispositions(value, raw):
    if not isinstance(value, list):
        raise AuditError("prior_dispositions must be an array", raw)
    return tuple(value)

def _validate_assessments(value, raw):
    if not isinstance(value, list):
        raise AuditError("prior_assessments must be an array", raw)
    return tuple(value)

def _one_line(value, name):
    if not isinstance(value, str) or not value.strip() or "\n" in value or "\r" in value:
        raise ValueError(name + " must be nonempty one-line text")
    return value
