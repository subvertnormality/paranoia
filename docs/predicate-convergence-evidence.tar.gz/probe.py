from pathlib import Path
from copy import deepcopy
from collections import Counter
import json, os, shutil, subprocess, sys, tempfile, time
ROOT=Path('/tmp/paranoia-predicate-probe')
SEED=Path('/tmp/paranoia-effectiveness-calibrated-2026-09-07/t029')
OUT=Path('/tmp/paranoia-predicate-continuation-2026-09-07')
os.environ.update(PATH='/home/andy/.local/bin:'+os.environ['PATH'],
                  GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_SYSTEM='/dev/null')
sys.path.insert(0,str(ROOT/'scripts'))
import benchmark_review_modes as shared
import benchmark_effectiveness as pilot
import effectiveness_custody as custody
from effectiveness_calibration import calibrate
def require(value,message):
    if not value: raise ValueError(message)
def inventory(root):
    return {str(p.relative_to(root)):shared.sha(p.read_bytes())
            for p in root.rglob('*') if p.is_file()}
def verify_snapshot(repo,case,fixture):
    require(shared.git(repo,'rev-parse','HEAD')==fixture['head'],'HEAD changed')
    require(not shared.git(repo,'status','--porcelain'),'working tree changed')
    require(shared.git(repo,'log','--format=%H%x09%aI%x09%an%x09%s','HEAD')==fixture['history'],'history changed')
    for ref in ('base','head'):
        require(shared.git(repo,'rev-parse',fixture[ref]+'^{tree}')==fixture[ref+'_tree'],'tree changed')
    for ref,files in ((fixture['base'],fixture['base_files']),(fixture['head'],case['files'])):
        require(shared.git(repo,'ls-tree','-r','--name-only',ref).splitlines()==sorted(files),'file inventory changed')
        for name,value in files.items():
            require(subprocess.check_output(['git','show',ref+':'+name],cwd=repo)==value.encode(),'committed bytes changed')
    for name,value in case['files'].items():
        require((repo/name).read_bytes()==value.encode(),'working bytes changed')
def qualify_continuation(directory,spec):
    q=custody.collect_slot(directory,spec)
    require(not q['errors'],'custody: '+repr(q['errors']))
    rows=q['attempts']
    require(len({r['sequence'] for r in rows})==len(rows),'duplicate attempt')
    expected={k.removeprefix('src/paranoia_local/'):v for k,v in spec['source']['files'].items()}
    for trace in q['traces']:
        for key in ('source_observed_at_import','source_observed_at_finish'):
            require(trace[key]['files']==expected,'native source differs')
            require(trace[key]['revision']==spec['source']['revision'],'native source revision differs')
        require(trace['source_changed_since_import'] is False,'native source changed')
    return q
def negative_checks(seed_spec):
    # These copies never invoke a provider; resealing isolates semantic custody checks.
    require(not custody.collect_slot(SEED,seed_spec)['errors'],'seed custody invalid')
    results=[]
    for mutation in ('channel','missing-audit','duplicate-attempt','head'):
        with tempfile.TemporaryDirectory(prefix='predicate-negative-') as tmp:
            d=Path(tmp)
            for name in custody.runtime_files(SEED):
                target=d/name;target.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(SEED/name,target)
            spec=deepcopy(seed_spec)
            if mutation=='channel':
                p=next(d.glob('provider-*.txt'));p.write_bytes(p.read_bytes()+b'altered')
            elif mutation=='missing-audit':
                next((d/'logs').glob('*critique_branch*')).unlink()
            elif mutation=='duplicate-attempt':
                p=d/'attempts.jsonl';p.write_text(p.read_text()+p.read_text().splitlines()[0]+'\n')
            else:
                spec['fixture']['head']='0'*40;shared.dump(d/'input.json',spec)
            custody.terminal(d,'completed')
            q=custody.collect_slot(d,spec)
            require(bool(q['errors']),mutation+' was not rejected')
            results.append({'mutation':mutation,'errors':q['errors']})
    return results
def main():
    started=time.perf_counter();OUT.mkdir(exist_ok=False)
    shutil.copy2(__file__,OUT/'probe.py')
    seed_inventory=inventory(SEED)
    original=custody.read(SEED/'input.json')
    source=shared.source_record(ROOT)
    require(source['files']==original['source']['files'],'production differs from seed')
    shared.validate_source(original['source'])
    tests=negative_checks(original)
    shared.dump(OUT/'negative-checks.json',tests)
    shutil.copytree(SEED/'repository',OUT/'repository')
    shutil.copytree(SEED/'state',OUT/'state')
    state_path=OUT/'state/lineages/pilot-t029.json'
    seed_state=state_path.read_bytes()
    require(seed_state==(SEED/'state/lineages/pilot-t029.json').read_bytes(),'seed state differs')
    (OUT/'seed-state.json').write_bytes(seed_state)
    repo=OUT/'repository'
    verify_snapshot(repo,original['case'],original['fixture'])
    before=(repo/'app.py').read_text()
    token='if not isinstance(index, int) or'
    require(before.count(token)==1,'repair site changed')
    (repo/'app.py').write_text(before.replace(token,'if isinstance(index, bool) or not isinstance(index, int) or'))
    shared.git(repo,'add','app.py')
    shared.git(repo,'-c','commit.gpgsign=false','commit','-qm','Reject Boolean evidence indexes')
    spec=deepcopy(original)
    spec['source']=source
    spec['case']['files']['app.py']=(repo/'app.py').read_text()
    spec['fixture']['head']=shared.git(repo,'rev-parse','HEAD')
    spec['fixture']['head_tree']=shared.git(repo,'rev-parse','HEAD^{tree}')
    spec['fixture']['history']=shared.git(repo,'log','--format=%H%x09%aI%x09%an%x09%s','HEAD')
    spec['counter']=str(OUT/'calls.txt');spec['maximum']=4
    spec['harness']={str(ROOT/'scripts'/Path(p).name):shared.sha((ROOT/'scripts'/Path(p).name).read_bytes()) for p in original['harness']}
    spec['harness'][str(OUT/'probe.py')]=shared.sha((OUT/'probe.py').read_bytes())
    sys.path.insert(0,str(ROOT/'src'))
    from paranoia_local import server,engines,orientation
    spec['fixture']['packet_sha256']=shared.sha(orientation.build_packet(repo,spec['fixture']['base'],spec['fixture']['head']))
    files={n:subprocess.check_output(['git','show','HEAD:'+n],cwd=repo).decode() for n in spec['case']['files']}
    calibration=calibrate('identity',files,False)
    witness=calibrate('identity',original['case']['files'],True)
    require(len(calibration['checks'])==100 and not calibration['target_failures'],'calibration failed')
    require([r['id'] for r in calibration['checks']]==[r['id'] for r in witness['checks']],'check set differs')
    require(all(not r['failures'] for r in calibration['checks']),'failed calibration check')
    require(calibration['files_sha256']=={n:shared.sha(t) for n,t in files.items()},'calibration binding differs')
    shared.dump(OUT/'calibration.json',calibration);shared.dump(OUT/'original-witness.json',witness)
    state=json.loads(seed_state);pattern=state['classes'][0]['pattern']
    match=subprocess.run(['grep','-nE',pattern,'app.py'],cwd=repo,text=True,capture_output=True)
    require(match.returncode==0,'historical predicate no longer matches')
    (OUT/'predicate-match.txt').write_text(match.stdout)
    (OUT/'repair.diff').write_text(shared.git(repo,'diff',original['fixture']['head'],'HEAD','--'))
    shared.dump(OUT/'input.json',spec);input_hash=shared.sha((OUT/'input.json').read_bytes())
    shared.dump(OUT/'seed-inventory.json',seed_inventory)
    frozen={n:shared.sha((OUT/n).read_bytes()) for n in ('input.json','calibration.json','original-witness.json','seed-state.json','repair.diff','predicate-match.txt','negative-checks.json','seed-inventory.json','probe.py')}
    def preflight(repo_to_check=repo,case=None,fixture=None):
        shared.validate_source(source);shared.validate_harness(spec['harness'])
        require(inventory(SEED)==seed_inventory,'sealed seed changed')
        require(all(shared.sha((OUT/n).read_bytes())==h for n,h in frozen.items()),'frozen probe input changed')
        verify_snapshot(repo_to_check,case or spec['case'],fixture or spec['fixture'])
    preflight()
    bad=deepcopy(spec['fixture']);bad['head']=bad['base']
    try: verify_snapshot(repo,spec['case'],bad)
    except ValueError: pass
    else: raise ValueError('snapshot negative control failed')
    for engine,version in spec['versions'].items():
        require(subprocess.check_output([engine,'--version'],text=True).strip()==version,'CLI version changed')
    require(state_path.read_bytes()==seed_state,'lineage modified before admission')
    shared.dump(OUT/'freeze.json',{'files':frozen,'input_sha256':input_hash,'snapshot_negative_control':'rejected'})
    setup_ms=round((time.perf_counter()-started)*1000)
    (OUT/'calls.txt').write_text('0')
    os.environ['PARANOIA_STATE_ROOT']=str(OUT/'state')
    original_admit=shared.admit
    def admit(counter):
        try:return original_admit(counter,maximum=4)
        except RuntimeError as exc:raise pilot.AdmissionRefused(str(exc)) from exc
    shared.admit=admit
    shared.install_observer(engines,OUT,OUT/'calls.txt')
    pilot.verify_fixture=lambda r,c,f:preflight(r,c,f)
    pilot.install_checks(engines,spec,repo,OUT)
    provider=spec['case']['provider'];dispatch_ms=0;failure=None;q=None
    try:
        for round_no in (2,3):
            preflight()
            args={'repo_path':str(repo),'engine':provider,'model':spec['models'][provider],
                  'effort':'high','web_search':False,'base_ref':spec['fixture']['base'],
                  'head_ref':spec['fixture']['head'],'lineage':'pilot-t029','round':round_no,'stakes':spec['stakes']}
            shared.dump(OUT/f'request-{round_no}.json',args)
            (OUT/f'state-before-{round_no}.json').write_bytes(state_path.read_bytes())
            shared.CURRENT_STAGE[0]='correction' if round_no==2 else 'final'
            print('CODE PROBE round',round_no,flush=True)
            call_started=time.perf_counter()
            try: result=server.dispatch('critique_branch',args,default_engine_name=provider,log_dir=OUT/'logs',on_progress=lambda s:print(s,flush=True))
            finally:
                elapsed=round((time.perf_counter()-call_started)*1000);dispatch_ms+=elapsed
            traces=[custody.read(p) for p in (OUT/'logs').glob('*.json')]
            traces=[t for t in traces if t.get('tool')=='run' and t.get('result_sha256')==shared.sha(result)]
            require(len(traces)==1,'missing unique dispatch trace')
            shared.dump(OUT/f'output-{round_no}.json',{'mode':'critique_branch','round':round_no,'result':result,'elapsed_ms':elapsed,'run_id':traces[0]['run_id']})
            (OUT/f'state-after-{round_no}.json').write_bytes(state_path.read_bytes())
            preflight()
            custody.terminal(OUT,'completed',elapsed_ms=round((time.perf_counter()-started)*1000),dispatch_ms=dispatch_ms)
            q=qualify_continuation(OUT,spec)
            require(Counter(r['sequence'] for r in q['attempts'])==Counter(range(1,int((OUT/'calls.txt').read_text())+1)),'call counter differs')
            require(q['execution_success'],'native execution unsuccessful')
            print(result,flush=True)
            if custody.read(state_path).get('review_state',{}).get('phase')!='final':break
    except Exception as exc:
        failure=type(exc).__name__+': '+str(exc)
    custody.terminal(OUT,'failed' if failure else 'completed',failure,elapsed_ms=round((time.perf_counter()-started)*1000),dispatch_ms=dispatch_ms)
    try:q=qualify_continuation(OUT,spec)
    except Exception as exc:failure=failure or str(exc)
    summary={'failure':failure,'setup_ms':setup_ms,'dispatch_ms':dispatch_ms,
             'elapsed_ms':round((time.perf_counter()-started)*1000),
             'calls':int((OUT/'calls.txt').read_text()),'seed_unchanged':inventory(SEED)==seed_inventory,
             'phase':custody.read(state_path).get('review_state',{}).get('phase'),
             'qualified':failure is None,'clear':bool(q and q['clear_eligible'] and not failure)}
    shared.dump(OUT/'summary.json',summary)
    shared.dump(OUT/'seal.json',inventory(OUT))
    print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__':main()
