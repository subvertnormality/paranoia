# Wire contract
The consumer parses the entire message as RFC 8259 JSON.
There is no preprocessing step.
The message must retain numeric threshold 0.1.
