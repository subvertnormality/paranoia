import os,sys,json,time,hashlib,subprocess
from pathlib import Path
root=Path("/home/andy/tools/paranoia-local")
os.chdir(root);sys.path.insert(0,str(root/"src"))
os.environ["PATH"]="/home/andy/.local/bin:"+os.environ["PATH"]
from paranoia_local import arbitrate_handler as ah
out=Path("/tmp/paranoia-142/native-2");out.mkdir(exist_ok=False)
repo=Path("/tmp/paranoia-142/native-1/repository")
def git(*args):
 return subprocess.check_output(["git","-C",str(repo),*args],text=True).strip()
paths=subprocess.check_output(["git","ls-files","src"],cwd=root,text=True).splitlines()
source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
revision=subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip()
for p in paths:
 assert (root/p).read_bytes()==subprocess.check_output(["git","show",revision+":"+p],cwd=root)
args={"repo_path":str(repo),"decision":"Choose a wire message for the receiver defined in POLICY.md.","options":[{"id":"json-object","statement":'Transmit the exact message {"threshold":0.1}.'},{"id":"commented-object","statement":'Transmit a leading line // threshold, then a newline and {"threshold":0.1}.'}],"stakes":"One trusted local user and OS. Incorrect syntax causes a rejected message and recoverable rework. No concurrency or adversarial local process.","context":"The governing external format is RFC 8259. Both alternatives must be assessed against its JSON grammar and the local receiver contract.","files":[{"path":"POLICY.md","reason":"Defines the receiver contract."}],"clean":False,"research":True,"models":{"codex":"gpt-6.1-sol","claude":"claude-opus-5-5"},"effort":"medium","order_seed":"paranoia-142-rfc8259-native-1"}
(out/"invocation.json").write_text(json.dumps(args,indent=2))
start=time.monotonic()
report=ah.arbitrate(args,log_dir=out/"logs",on_progress=lambda x:print(x,flush=True))
elapsed=time.monotonic()-start
(out/"report.txt").write_text(report)
fields=dict(line.split(": ",1) for line in report.splitlines() if ": " in line and line.split(": ",1)[0].isupper())
audit_path=Path(fields["AUDIT"]);raw=audit_path.read_bytes();audit=json.loads(raw)
summary=audit["research"]["summary"]
calls=sum(r["calls"] for r in audit["research"]["runs"])+sum(len(d["attempts"]) for rnd in audit["rounds"] for d in rnd.values())+len(audit["phase_attempts"])
checks={"converged":fields["ARBITRATION"]=="CONVERGED","expected_selection":fields["SELECTED"]=="json-object","research_enabled":audit["research"]["enabled"],"both_completed_research":len(audit["research"]["runs"])==2,"capture_completed":summary["usable_captures"]>0,"binding_completed":summary["bound_sources"]>0,"governing_packets":summary["governing_packets"]>0,"report_counts":all(f"{k}={v}" in fields["RESEARCH"].split("; ") for k,v in summary.items()),"packet_digest":fields["RESEARCH-DIGEST"]==audit["research"]["digest"],"unchanged_source":all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in source.items())}
receipt={"qualified":all(checks.values()),"source_revision":revision,"source_sha256":source,"models":args["models"],"clean":False,"research":True,"audit_path":str(audit_path),"audit_sha256":hashlib.sha256(raw).hexdigest(),"report_sha256":hashlib.sha256(report.encode()).hexdigest(),"calls":calls,"elapsed_seconds":elapsed,"summary":summary,"checks":checks}
(out/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt,indent=2),flush=True)
print(report[-2500:],flush=True)
assert receipt["qualified"],"Native research-enabled acceptance failed; retain artifacts."
