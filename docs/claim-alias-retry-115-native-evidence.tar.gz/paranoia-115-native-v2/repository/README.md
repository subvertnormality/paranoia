# Local label fixture
The application displays a local label.
