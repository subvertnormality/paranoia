from pathlib import Path
import dataclasses, hashlib, json, os, subprocess, sys, threading, time, traceback
ROOT = Path("/home/andy/tools/paranoia-local/.worktrees/claim-alias-retry-115")
os.chdir(ROOT)
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))
os.environ["PATH"] = "/home/andy/.local/bin:" + os.environ["PATH"]
os.environ["GIT_CONFIG_GLOBAL"] = "/dev/null"
os.environ["GIT_CONFIG_SYSTEM"] = "/dev/null"
OUT = Path("/tmp/paranoia-115-native")
OUT.mkdir(exist_ok=False)
os.environ["PARANOIA_STATE_ROOT"] = str(OUT / "state")
from paranoia_local import class_closure as cc, plan_claims as pc, engines, server, external_sources
from scripts import benchmark_review_modes as bm
# Use the documented state override, asserting it before any provider spend.
print("STATE_ROOT", cc.default_state_root(), flush=True)
assert cc.default_state_root() == OUT / "state"
def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=True) + "\n")
source = bm.source_record(ROOT)
write("source.json", source)
(OUT / "driver.py").write_bytes(Path(__file__).read_bytes())
write("runtime.json", {"claude_version": subprocess.check_output(["claude", "--version"],text=True).strip(),
                      "python":sys.version, "source_revision":source["revision"], "ceiling":12})
repo = OUT / "repository"
repo.mkdir()
(repo / "README.md").write_text("# Local label fixture\nThe application displays a local label.\n")
(repo / "app.py").write_text('LABEL = "Ready"\n')
for args in (["init", "-q"], ["add", "."], ["-c","user.name=Codex","-c","user.email=codex@openai.com","commit","-qm","Fixture"]):
    subprocess.run(["git",*args],cwd=repo,check=True)
old_plan = "# Rollout\n\nPython 3.11 was released in October 2022.\n"
plan = "# Local label\n\nKeep the displayed label as Ready. This is a project choice.\n"
claim = {"kind":"fact","scope":"external","anchor":old_plan.splitlines()[-1],
         "proposition":old_plan.splitlines()[-1],"prior_claim_id":None,"verdict":"unverified",
         "evidence":[],"replacement":None,"rationale":"Synthetic unverified prior claim used only to test retirement."}
payload = {"claims":[claim],"coverage":{"sections_scanned":1,"omitted_nonfacts":0,
           "prior_assessments":[],"prior_dispositions":[],"notes":"Synthetic prior state, not external evidence."}}
lineage = "issue115-native-opus"
prior = pc.reconcile({}, pc.parse_audit(pc.AUDIT_MARKER+"\n"+json.dumps(payload),old_plan),
                     lineage_id=lineage,round_no=1,plan_text=old_plan)
cc.save_lineage(cc.default_state_root(), cc.Lineage(lineage,mode=cc.PLAN_MODE,rounds=1,claim_state=prior))
write("seed.json", {"old_plan":old_plan,"prior_claim_state":prior,"current_plan":plan})
original = engines.Engine._execute
lock = threading.Lock()
count = [0]
def observe(self, argv, prompt, cwd, runner, timeout, on_progress=None, response_schema=None):
    with lock:
        if count[0] >= 12:
            raise RuntimeError("native issue115 attempt ceiling exceeded")
        count[0] += 1
        sequence = count[0]
    assert runner is None
    row = {"sequence":sequence,"role":self.role,"argv":argv,"cwd":str(cwd),
           "prompt":prompt,"response_schema":response_schema,"timeout":timeout}
    write(f"attempt-{sequence:02d}-input.json",row)
    started = time.monotonic()
    try:
        result = original(self,argv,prompt,cwd,runner,timeout,on_progress,response_schema)
        write(f"attempt-{sequence:02d}-output.json", dataclasses.asdict(result))
        return result
    finally:
        write(f"attempt-{sequence:02d}-duration.json",{"elapsed_ms":round((time.monotonic()-started)*1000)})
engines.Engine._execute = observe
capture_original = external_sources.capture_all
captures = []
def capture(candidates, **kwargs):
    captures.extend(candidates)
    return capture_original(candidates, **kwargs)
external_sources.capture_all = capture
stakes = "One trusted local operator and OS; static plan/repository/provider data; no repository-selected code execution by reviewers or hostile local races. One tiny repository, one absent synthetic unverified claim, no current external assertions; normal native reviewer concurrency/network boundaries and timeouts. False clearance and wrong binding are high impact; recoverable blocking acceptable. No multi-tenancy, compromised OS or corrupted-state recovery."
arguments = {"repo_path":str(repo),"plan_text":plan,"lineage":lineage,"round":2,
             "model":"opus","effort":"high","claim_verification":True,"web_search":False,"stakes":stakes}
write("invocation.json", arguments)
started = time.monotonic()
try:
    result = server.dispatch("critique_plan",arguments,default_engine_name="claude",log_dir=OUT/"logs")
    (OUT/"result.txt").write_text(result)
    state = cc.load_lineage(cc.default_state_root(),lineage,stamp="post",mode=cc.PLAN_MODE)
    write("durable.json",cc._to_json(state))
    bm.validate_source(source)
    audits = list((OUT/"logs").glob("*-critique_plan-*.json"))
    assert len(audits)==1
    audit = json.loads(audits[0].read_text())
    attempts = audit["attempt_ledger"]
    assert len(attempts)==count[0] <=12
    assert not captures and not state.claim_state["claims"] and not pc.is_blocked(state.claim_state)
    assert not any(x["outcome"] not in {"completed","validation-invalid"} for x in attempts)
    assert any(x.startswith("CONVERGENCE: NOT-BLOCKED") for x in result.splitlines())
    write("qualification.json",{"qualified":True,"attempts":count[0],"capture_count":len(captures),
          "elapsed_ms":round((time.monotonic()-started)*1000),
          "discovery_attempts":sum(x["role"].startswith("claim-discovery") for x in attempts),
          "scope":"Native prevention/usability unless a natural collision and repair is actually retained; exact failure injection is deterministic regression evidence."})
    print("QUALIFIED",count[0], flush=True)
except BaseException as exc:
    write("qualification.json",{"qualified":False,"attempts":count[0],"error":repr(exc),
          "traceback":traceback.format_exc(),"elapsed_ms":round((time.monotonic()-started)*1000)})
    raise
